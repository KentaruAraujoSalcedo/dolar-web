// ==============================
// File: scripts/ui/dom.js
// ==============================

export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));